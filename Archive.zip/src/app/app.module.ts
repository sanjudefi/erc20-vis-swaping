import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BuyVistTokenComponent } from './pageComponents/buy-vist-token/buy-vist-token.component';
import { SwapUsdtComponent } from './pageComponents/swap-usdt/swap-usdt.component';
import { NavbarComponent } from './sharedComponents/navbar/navbar.component';
import { WyreComponent } from './pageComponents/wyre/wyre.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { WireEthComponent } from './pageComponents/wire-eth/wire-eth.component';


@NgModule({
  declarations: [
    AppComponent,
    BuyVistTokenComponent,
    SwapUsdtComponent,
    NavbarComponent,
    WyreComponent,
    WireEthComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,

    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
