import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WyreComponent } from './wyre.component';

describe('WyreComponent', () => {
  let component: WyreComponent;
  let fixture: ComponentFixture<WyreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WyreComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WyreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
