import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwapUsdtComponent } from './swap-usdt.component';

describe('SwapUsdtComponent', () => {
  let component: SwapUsdtComponent;
  let fixture: ComponentFixture<SwapUsdtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SwapUsdtComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SwapUsdtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
