import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StorageService } from 'src/app/services/storage.service';
import { AccountService } from 'src/app/services/account.service';
import { environment } from 'src/environments/environment.prod';
import { SwapContractService } from 'src/app/services/swap-contract.service';
import { PricingService } from 'src/app/services/pricing.service';
import { ContractService } from 'src/app/services/contract.service';

import Web3 from 'web3';

// Connect Wallet
import WalletConnect from "@walletconnect/client";
import QRCodeModal from "@walletconnect/qrcode-modal";
import { decimalDigest } from '@angular/compiler/src/i18n/digest';
import { ConnectionService } from 'src/app/services/connection.service';
// Set web3 and connector
const web3 = new Web3(window['ethereum'] || environment.BSC_PROVIDER);
let connector = new WalletConnect({
  bridge: "https://bridge.walletconnect.org"
});


@Component({
  selector: 'app-swap-usdt',
  templateUrl: './swap-usdt.component.html',
  styleUrls: ['./swap-usdt.component.css']
})
export class SwapUsdtComponent implements OnInit {
  @ViewChild('uiWallet') uiWallet;
  @ViewChild('uiRegisterForm') uiRegisterForm;
  ethereum: any;
  alertSuccess: boolean = true;
  account: any = {};
  connector: any;
  swapForm: FormGroup;
  getChainIdInterval: any;
  submitted: boolean = false;
  approved: boolean = false;
  loading: boolean = false;
  transactionHash: any;
  transactionHashStatus: boolean = false;
  usdtBalance: number = 0;
  ektaBalance: number = 0;
  network:"";
  totalStake: any;
  evisBalance: number = 0;
  tierOneAvailable: any = '-'; 
  tierTwoAvailable: any = '-'; 
  tierThreeAvailable: any = '-';


  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private storageService: StorageService,
    private accountService: AccountService,
    private swapContractService: SwapContractService,
    private ContractService: ContractService,
    private pricingService: PricingService,
    private connectionService: ConnectionService
  ) { }
  ngOnInit(): void {
    this.swapForm = this.formBuilder.group({
      network: ['', [Validators.required]],
      usdtAmount: ['', [Validators.required]],
      ektaAmount: ['', [Validators.required]]
    })
    this.account = this.storageService.getItem('account') === null ? { address: "", network: "", chainId: "", provider: "" } : JSON.parse(this.storageService.getItem('account'));
    this.setAccount(this.account.address, this.account.chainId, this.account.provider);
if (this.account.provider === 'metamask') {
  this.ethereum = window['ethereum'];
  this.metamastListener();
} else if (this.account.provider === 'trustwallet') {
  this.connector = new WalletConnect({
    bridge: "https://bridge.walletconnect.org", // Required
  });
  this.wallectConnectListener();
  
}
this.getDecimals();
this.getUsdtBalance();
  // this.getEktaBalance();
this.getChainIdInterval =  setInterval(() => this.getChainId(), 500)
window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.ETH_CHAINID}]}))
this.swapForm.patchValue({network: 'ETH'});

this.evisBalanceUpdate();
  this.connectionService.listenConnection$.subscribe((connection:any) => {
    if (typeof connection == 'string') {
      this.connectMetamask();
    }
  })

  }
  get getSwapForm() { return this.swapForm.controls; }

  async evisBalanceUpdate() {
    await this.ContractService.getEvisBalance(this.account.address).then(async (balance) => {
      // balance = Number(web3.utils.fromWei(balance, await this.getDecimals()));
      this.evisBalance = Number(balance) / 1000000000000000000; //Number(web3.utils.fromWei(balance, await this.getDecimals()));
    });
  }
  async getUsdtBalance() {
    let network = this.getSwapForm.network.value;
    let usdtToken = await this.swapContractService.getSwapFromToken('ETH');
    this.usdtBalance = Number(web3.utils.fromWei(await this.swapContractService.getSwapFromTokenBalance(usdtToken, this.account.address, network), await this.getDecimals()));
    console.log('usdt', this.usdtBalance, await this.getDecimals())
    console.log(usdtToken);
    await this.swapContractService.getTierAvailabilities(this.account.network).then((data:any) => {
      console.log('tier', data);
      this.tierOneAvailable = data.tierOneAvailable; 
      this.tierTwoAvailable = data.tierTwoAvailable; 
      this.tierThreeAvailable = data.tierThreeAvailable;
    });
  }

  async getEktaBalance() {
    // let web3Ekta = new Web3(environment.EKTA_PROVIDER);
    // let balance = await web3Ekta.eth.getBalance(this.account.address);
    // this.ektaBalance = Number(web3.utils.fromWei(balance, 'ether'));
  }

  public async setAccount(address, chainId, provider) {
    let account;
    if (address != "") {
      account = { address: address, chainId: chainId, network: await this.setNetwork(chainId), provider: provider }
    } else {
      account = { address: "", network: "", chainId: "", provider: "" };
    }
    if (address == undefined) {
      account = { address: "", network: "", chainId: "", provider: "" };
    }
    this.accountService.setAccount(account);
    this.account = Object.assign({}, account);
    this.storageService.setItem('account', JSON.stringify(this.account));
    
  }
  getChainId = async () => {
    this.setNetwork(this.account.chainId);
  }

  networkChange(event) {
    try {

      if(this.account.address !== "") {
        this.swapForm.patchValue({network: event.target.value});
        this.ContractService.stakedAmountOf(this.account.address).then(response => {
          this.totalStake = response; 
          console.log("response",response);
        })
        if(event.target.value === 'ETH' && this.account.chainId != environment.ETH_CHAINID) {
          window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.ETH_CHAINID}]}))
        }
        if(event.target.value === 'BSC' && this.account.chainId != environment.BSC_CHAINID) {
          window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.BSC_CHAINID}]})).catch((err) => {
            console.log(err.code);
            if (err.code == 4902) {
              alert('Add Bsc chain first');
            }
          });
        }
  
        this.getUsdtBalance();
        this.getEktaBalance();
      } else {
        this.toastr.error("Connect wallet to proceed with swap")
      }
    } catch (error) {
      console.log('Error on networkchange', error);
    }
    
  }


  /**
   * 
   * @param tier 
   */
  public getValueByTier(tier: number) {
    switch (tier) {

      case 1:
        return 0.14;
        break;

      case 2:
        return 0.16;
        break;

      case 3:
        return 0.18;
        break;

      case 4:
        return 0.20;
        break;
    
      default:
        return false
        break;
    }
  }

  public wallectConnectListener() {
    // Subscribe to connection events
    this.connector.on("connect", (error, payload) => {
      window.location.reload();
      if (error) {
        throw error;
      }
      // Get provided accounts and chainId
      const { accounts, chainId } = payload.params[0];
      this.setAccount(accounts[0], chainId, 'trustwallet');
    });

    this.connector.on("session_update", (error, payload) => {
      if (error) {
        throw error;
      }
      // Get updated accounts and chainId
      const { accounts, chainId } = payload.params[0];
      this.setAccount(accounts[0], chainId, 'trustwallet');
    });

    this.connector.on("disconnect", (error, payload) => {
      if (error) {
        throw error;
      }

      // Delete connector
      this.setAccount("", "", "");
      this.storageService.setItem("token","");
    });
    this.alertSuccess = true;
    this.timeOut();
  }
  public metamastListener() {
    // Listener
    this.ethereum.on('accountsChanged', (accounts) => {
      this.setAccount(accounts[0], this.ethereum.chainId, 'metamask');
      location.reload();
    });
    this.ethereum.on('chainChanged', (chainId) => {
      this.setAccount(this.account.address, chainId, 'metamask');
    });
    this.ethereum.on('close', (chainId) => {
      this.setAccount("", "", "");
      this.storageService.setItem("token","");
    });
    this.alertSuccess = true;
    this.timeOut();
    this.storageService.setItem("walletconnect","");
  }
  connectMetamask = async () => {
    this.ethereum = window['ethereum'];
    if (typeof this.ethereum !== 'undefined') {
    }
    const accounts = await this.ethereum.request({ method: 'eth_requestAccounts' });
    this.setAccount(accounts[0], this.ethereum.chainId, 'metamask');
    this.metamastListener();
    this.getDecimals();
    this.getUsdtBalance();
  }
  async getAllowance() {
   
    
    let network = this.getSwapForm.network.value;
    let usdtToken = await this.swapContractService.getSwapFromToken(network);
    let allowance = await this.swapContractService.allowance(usdtToken, this.account.address, network === 'ETH' ? environment.ETH_SWAP_CONTRACT : environment.SWAP, network);
    
    console.log(Number(web3.utils.toWei(this.getSwapForm.usdtAmount.value.toString())));
    console.log('allowance', allowance);
    
    if(allowance >= Number(this.getSwapForm.ektaAmount.value)) {
      this.approved = true;
    } else {
      this.approved = false;
    }
    console.log('1st',(Number(allowance) / 10**6));
    console.log('2nd',Number(this.getSwapForm.ektaAmount.value) );
    console.log('approve',this.approved);
    
    // console.log('Number(web3.utils.toWei(this.getSwapForm.usdtAmount.value.toString()))',Number(this.convert(web3.utils.toWei(this.getSwapForm.usdtAmount.value.toString())))); 
    
    
  }
  async approve() {
    this.submitted = true;
    if(this.swapForm.invalid) {
      return;
    }
    if(this.getSwapForm.ektaAmount.value <= 0) {
      this.toastr.error("Entered amount is not greater than 0")
      return true;
    }
    if(this.getSwapForm.ektaAmount.value > this.usdtBalance) {
      this.toastr.error("Entered amount is greater than balance")
      return true;
    }

    this.loading = true;
    let network = this.getSwapForm.network.value;
    
    if(network === 'ETH' && this.account.chainId != environment.ETH_CHAINID) {
      window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.ETH_CHAINID}]}))
      .then(response => this.approveToken(network))
      .catch(error => {
        this.loading = false;
        this.toastr.error("User rejected the request")
      });
    }
    else if(network=== 'BSC' && this.account.chainId != environment.BSC_CHAINID) {
      window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.BSC_CHAINID}]}))
      .then(response => this.approveToken(network))
      .catch(error => {
        this.loading = false;
        this.toastr.error("User rejected the request")
      });
    } else {
      this.approveToken(network)
    }
  }
  async approveToken(network) {
    let usdtToken = await this.swapContractService.getSwapFromToken(network);

    let approveAbi = await this.swapContractService.approve(usdtToken, network === 'ETH' ? environment.ETH_SWAP_CONTRACT : environment.SWAP, web3.utils.toWei((this.getSwapForm.ektaAmount.value).toString(), await this.getDecimals()), network);

    let message = {
      method: 'eth_sendTransaction', 
      from: web3.utils.toChecksumAddress(this.account.address),
      to: environment.ETH_APPROVE,
      data: approveAbi,
      chainId: this.account.chainId
    }
console.log("message",message);
    web3.eth.sendTransaction(message)
      .then(async (receipt) => {
        this.approved = true;
        this.loading = false;
        this.toastr.success("Approved successfully");
      })
      .catch((error) => {
        this.loading = false;
        if (error.code === 4001) this.toastr.error('User rejected'); 
        else this.toastr.error('Transaction Failed');
      })
  }

  async getDecimals() {
    let network = this.account.chainId == environment.ETH_CHAINID ? 'ETH' : this.account.chainId == environment.BSC_CHAINID ? 'BSC' : "";
    let decimals;
    if(network === 'ETH') decimals = 'Mwei';
    else decimals = 'ether';

    return decimals;
  }
  async usdtAmountChange(value) {
    this.transactionHash = "";
    this.transactionHashStatus = false;
    await this.swapContractService.swapCalculate(this.account.network, this.account.address)
    .then((tierInformation:any) => {
      const tier = tierInformation[0];
      const tierBalance = tierInformation[1];
      let ektaAmount = Number(value) / Number(this.getValueByTier(parseInt(tier)));
      this.swapForm.patchValue({usdtAmount: ektaAmount.toFixed(5)});
    }).catch((error:any) => {
      console.log('error occurred on swapCalculate', error);
    });
    this.getAllowance();
  }
  
  public setNetwork(chainId) {
    let network;
    switch (chainId) {
      case '0x1':
      case 1:
        network = "Mainnet";
        break;
      case '0x4':
      case 4:
        network = "Rinkeby";
        break;
      case '0x38':
      case 56:
        network = 'BSC Mainnet';
        break;
      case '0x61':
      case 97:
        network = 'BSC Testnet';
        break;
      case '0x3ec':
      case 1004:
        network = 'EktaChain Testnet';
        break;
      case '0x7ca':
      case 1994:
        network = 'EktaChain';
        break;
      default:
        network = 'Unknown';
        break;
    }
    return network;
  }

  timeOut(){
    setTimeout(()=>{
      this.alertSuccess = false;
  }, 5000);
  
   }

   async onSubmit() {
    this.submitted = true;
    let network = this.getSwapForm.network.value;

    if(this.swapForm.invalid) {
      return;
    }
    if(this.getSwapForm.ektaAmount.value <= 0) {
      this.toastr.error("Entered amount is not greater than 0")
      return true;
    }
    if(this.getSwapForm.ektaAmount.value > this.usdtBalance) {
      this.toastr.error("Entered amount is greater than balance")
      return true;
    }

    this.loading = true;
    if(network === 'ETH' && this.account.chainId != environment.ETH_CHAINID) {
      window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.ETH_CHAINID}]}))
      .then(response => this.swapToken(network))
      .catch(error => {
        this.loading = false;
        this.toastr.error("User rejected the request")
      });
    }
    else if(network=== 'BSC' && this.account.chainId != environment.BSC_CHAINID) {
      window['ethereum'].request(({ method: 'wallet_switchEthereumChain', params:[{chainId: environment.BSC_CHAINID}]}))
      .then(response => this.swapToken(network))
      .catch(error => {
        this.loading = false;
        this.toastr.error("User rejected the request")
      });
    } else {
      this.swapToken(network);
    }
  }

  async swapToken(network){
    console.log("this.getSwapForm.usdtAmount.value",(this.getSwapForm.ektaAmount.value) * 10*6);
    let sss = web3.utils.toWei((this.getSwapForm.usdtAmount.value ));
    console.log("sss",(this.getSwapForm.usdtAmount.value))
    let swapAbi = await this.swapContractService.swap((web3.utils.toWei((this.getSwapForm.ektaAmount.value).toString(), await this.getDecimals())),(web3.utils.toWei((this.getSwapForm.usdtAmount.value).toString(), await this.getDecimals())), network);
    console.log("swapAbi",swapAbi);
    let message = {
      method: 'eth_sendTransaction', 
      from: this.account.address,
      to: network === 'ETH' ? environment.ETH_SWAP_CONTRACT : environment.SWAP,
      data: swapAbi,
      chainId: this.account.chainId
    }
console.log("message",message);
    web3.eth.sendTransaction(message)
      .then(async (receipt) => {
        this.loading = false;
        this.submitted = false;
        this.swapForm.reset();
        this.swapForm.patchValue({network});
        this.getUsdtBalance();
        this.getEktaBalance();
        this.transactionHash = receipt.transactionHash;
        this.transactionHashStatus = true;
        this.toastr.success("Swapped successfully");
      })
      .catch((error) => {
        this.loading = false;
        if (error.code === 4001) this.toastr.error('User rejected'); 
        else this.toastr.error('Transaction Failed');
      })
  }

   convert(n){
    var sign = +n < 0 ? "-" : "",
        toStr = n.toString();
    if (!/e/i.test(toStr)) {
        return n;
    }
    var [lead,decimal,pow] = n.toString()
        .replace(/^-/,"")
        .replace(/^([0-9]+)(e.*)/,"$1.$2")
        .split(/e|\./);
    return +pow < 0 
        ? sign + "0." + "0".repeat(Math.max(Math.abs(pow)-1 || 0, 0)) + lead + decimal
        : sign + lead + (+pow >= decimal.length ? (decimal + "0".repeat(Math.max(+pow-decimal.length || 0, 0))) : (decimal.slice(0,+pow)+"."+decimal.slice(+pow)))
}

}
