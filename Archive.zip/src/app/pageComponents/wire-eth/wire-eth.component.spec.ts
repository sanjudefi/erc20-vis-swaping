import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WireEthComponent } from './wire-eth.component';

describe('WireEthComponent', () => {
  let component: WireEthComponent;
  let fixture: ComponentFixture<WireEthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WireEthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WireEthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
