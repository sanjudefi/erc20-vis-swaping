import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyVistTokenComponent } from './buy-vist-token.component';

describe('BuyVistTokenComponent', () => {
  let component: BuyVistTokenComponent;
  let fixture: ComponentFixture<BuyVistTokenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyVistTokenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyVistTokenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
