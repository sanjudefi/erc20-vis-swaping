import { Component, OnInit } from '@angular/core';
import Web3 from 'web3';
import { AccountService } from 'src/app/services/account.service';
import { StorageService } from 'src/app/services/storage.service';
import { ContractService } from 'src/app/services/contract.service';
// Connect Wallet
import WalletConnect from "@walletconnect/client";
import QRCodeModal from "@walletconnect/qrcode-modal";
import { ToastrService } from 'ngx-toastr';
import { environment } from 'src/environments/environment.prod';
import { SwapContractService } from 'src/app/services/swap-contract.service';

// Set web3 and connector
const web3 = new Web3(window['ethereum'] || environment.BSC_PROVIDER);
let connector = new WalletConnect({
  bridge: "https://bridge.walletconnect.org"
});

@Component({
  selector: 'app-buy-vist-token',
  templateUrl: './buy-vist-token.component.html',
  styleUrls: ['./buy-vist-token.component.css']
})
export class BuyVistTokenComponent implements OnInit {
  ethereum: any;
  account: any = {};
  alertSuccess: boolean = true;
  connector: any;
  getChainIdInterval: any;
  totalStake: any;
  tier: number = 0;
  tierOneAvailable: any = '-'; 
  tierTwoAvailable: any = '-'; 
  tierThreeAvailable: any = '-';

  constructor(
    private accountService: AccountService, 
    private storageService: StorageService, 
    private toastr: ToastrService,
    private ContractService: ContractService,
    private swapContractService: SwapContractService
  ) { }

  ngOnInit(): void {
    this.account = this.storageService.getItem('account') === null ? { address: "", network: "", chainId: "", provider: "" } : JSON.parse(this.storageService.getItem('account'));
    this.setAccount(this.account.address, this.account.chainId, this.account.provider);
    this.accountService.account.subscribe(response => {
      this.account = response;
      this.getTiers();
    })
    
    if (this.account.provider === 'metamask') {
      this.ethereum = window['ethereum'];
      this.metamastListener();
    } 
    this.getChainIdInterval =  setInterval(() => this.getChainId(), 500)
    setTimeout(() => {
      this.getTiers();
    },500)
      

    this.accountService.connectionObserve.subscribe(response => {
      if(response.status == true){
        this.connectMetamask();
      }
    });

  }

 async getTiers(){
      await this.swapContractService.getTierAvailabilities(this.account.network).then((data:any) => {
        console.log('tier', data);
        this.tierOneAvailable = data.tierOneAvailable; 
        this.tierTwoAvailable = data.tierTwoAvailable; 
        this.tierThreeAvailable = data.tierThreeAvailable;
      });

     if(this.account.address != ""){
       console.log(this.account.network, this.account.address);
       
      await this.swapContractService.swapCalculate(this.account.network, this.account.address)
      .then((tierInformation:any) => {
        console.log(tierInformation);
        
        this.tier = Number(tierInformation[0]);
      }).catch((error:any) => {
        console.log('error occurred on swapCalculate', error);
      });
       this.ContractService.stakedAmountOf(this.account.address).then(response => {
           this.totalStake = response; 
         console.log("response",response);
       })
     }
    // stakedAmountOf
  }

  ngOnDestroy(){
    clearInterval(this.getChainIdInterval);
  }

  getChainId = async () => {
    this.setNetwork(this.account.chainId);
  }
  
  // Meta mask connection
  connectMetamask = async () => {
    this.ethereum = window['ethereum'];
    if (typeof this.ethereum !== 'undefined') {
    }
    const accounts = await this.ethereum.request({ method: 'eth_requestAccounts' });
    this.setAccount(accounts[0], this.ethereum.chainId, 'metamask');
    this.metamastListener();
  }

  public metamastListener() {
    // Listener
    this.ethereum.on('accountsChanged', (accounts: any[]) => {
      this.setAccount(accounts[0], this.ethereum.chainId, 'metamask');
    });
    this.ethereum.on('chainChanged', (chainId: any) => {
      this.setAccount(this.account.address, chainId, 'metamask');
    });
    this.ethereum.on('close', (chainId: any) => {
      this.setAccount("", "", "");
      this.storageService.setItem("token","");
    });
    this.alertSuccess = true;
    this.timeOut();
    this.storageService.setItem("walletconnect","");
  }
  /**
   * Store account details
   * @param address 
   * @param chainId 
   * @param provider 
   */
  public async setAccount(address: string | undefined, chainId: string, provider: any) {
    let account;
    if (address != "") {
      account = { address: address, chainId: chainId, network: await this.setNetwork(chainId), provider: provider }
    } else {
      account = { address: "", network: "", chainId: "", provider: "" };
    }
    if (address == undefined) {
      account = { address: "", network: "", chainId: "", provider: "" };
    }
    this.accountService.setAccount(account);
    this.account = Object.assign({}, account);
    this.storageService.setItem('account', JSON.stringify(this.account));
  }

 /**
  * Network Details
  * @param chainId 
  * @returns 
  */
  public setNetwork(chainId: any) {
    let network;
    switch (chainId) {
      case '0x1':
      case 1:
        network = "Mainnet";
        break;
      case '0x4':
      case 4:
        network = "Rinkeby";
        break;
      case '0x38':
      case 56:
        network = 'BSC Mainnet';
        break;
      case '0x61':
      case 97:
        network = 'BSC Testnet';
        break;
      case '0x3ec':
      case 1004:
        network = 'EktaChain Testnet';
        break;
      case '0x7ca':
      case 1994:
        network = 'EktaChain';
        break;
      default:
        network = 'Unknown';
        break;
    }
    return network;
  }

  timeOut(){
    setTimeout(()=>{
      this.alertSuccess = false;
  }, 5000);
  
   }

   addEktaMainet(){
    window['ethereum'].request({ 
      method: 'wallet_addEthereumChain',
      params: [{
      chainId: '0x7ca',
      chainName: 'EktaChain',
      nativeCurrency: {
          name: 'EktaChain',
          symbol: 'EKTA',
          decimals: 18
      },
      rpcUrls: ['https://main.ekta.io'],
      blockExplorerUrls: ['https://ektascan.io']
      }]
    })
    .then((success) => {
      console.log("receipt",success);
      this.toastr.success("Network Added Successfully");
    })
    .catch((error) => {
      console.log("error",error);
      if (error.code === 4001){
        this.toastr.error('User rejected');
      }
      else{
        this.toastr.error("Something went wrong");
      }
    });
  }

  async addVisToken(){
    // this.addToken.nativeElement.click();
    if(this.account.chainId == '' || this.account.chainId == undefined){
      // this.uiWallet.nativeElement.click();
      let account = { status: true };
      this.accountService.connectionStatus(account);
    }
    else if(this.account.chainId != '0x7ca'){
      await window['ethereum'].request({ method: 'wallet_switchEthereumChain', params:[{chainId: '0x7ca'}]});
        setTimeout(()=>  this.importVisToken(), 500)
      return;
    }
    else{
      this.importVisToken();
    }
  }

  importVisToken(){
    window['ethereum'].request({
     method: 'wallet_watchAsset',
     params: {
       type: 'ERC20',
       options: {
         address: '0xb64941515eD1eb61FeFCA7734Cf99D9c746C288D',
         symbol: 'eVIS',
         decimals: 18,
         image: 'https://assets.coingecko.com/coins/images/23907/small/J3JCKVq2.png?1645681725',
       },
     },
   })
   .then((success) => {
   })
   .catch((error) => {
    });
 }
 
 disconnect(){
  this.storageService.setItem('walletconnect', "");
   this.account = { address: "", network: "", chainId: "", provider: "" };
  this.accountService.setAccount(this.account);
  this.account = Object.assign({}, this.account);
  this.storageService.setItem('account', JSON.stringify(this.account));
}

}
