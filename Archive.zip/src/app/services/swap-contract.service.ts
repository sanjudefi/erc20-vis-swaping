import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod'; 
import Web3 from 'web3';

const web3Eth = new Web3(environment.ETH_PROVIDER);
const web3Bsc = new Web3(environment.BSC_PROVIDER);

const ethAbi = require('src/contracts/abi/eth.json');
const swapAbi = require('src/contracts/abi/bscswap.json');
const ethapproveAbi = require('src/contracts/abi/ethapprove.json');


const ethapproveContract = new web3Eth.eth.Contract(ethapproveAbi, environment.ETH_APPROVE);
const ethContract = new web3Eth.eth.Contract(ethAbi, environment.ETH_SWAP_CONTRACT);
const bscContract = new web3Bsc.eth.Contract(swapAbi, environment.SWAP);

@Injectable({
  providedIn: 'root'
})
export class SwapContractService {

  constructor() { }

  async getSwapFromToken(network){
    console.log('network', network)
    let token = network === 'ETH' ? await ethContract.methods.swapToken().call() : await bscContract.methods.swapToken().call();
    console.log('token', token)
    return "token";
  }

  async getTierAvailabilities(network) {
    if (network === 'ETH' || network == 'Mainnet') {
      
      const tier1Total = await ethContract.methods.tier1().call();
      const tier1PreCap = await ethContract.methods.tier1PreCappedAmount().call();
      console.log(tier1Total, tier1PreCap);
      const tierOneAvailable = Number(tier1Total) - Number(tier1PreCap);

      const tier2Total = await ethContract.methods.tier2().call();
      const tier2PreCap = await ethContract.methods.tier2PreCappedAmount().call();
      const tierTwoAvailable = Number(tier2Total) - Number(tier2PreCap);

      const tier3Total = await ethContract.methods.tier3().call();
      const tier3PreCap = await ethContract.methods.tier3PreCappedAmount().call();
      const tierThreeAvailable = Number(tier3Total) - Number(tier3PreCap);

      return { tierOneAvailable, tierTwoAvailable, tierThreeAvailable };
    } else {
      return false;
    }
    
  }
  /**
   * method to get tier and tier balance
   * @param network 
   * @param address 
   * @returns 
   */
  async swapCalculate(network, address) {
    if (network === 'ETH' || network == 'Mainnet') {
      const tierInfo =  await ethContract.methods.swapCalculate(address).call();
      return tierInfo;
    } else {
      const tierInfo =  await bscContract.methods.swapCalculate(address).call();
      return tierInfo;
    }
  }
  async getSwapFromTokenBalance(usdtAddress, address, network){
    // const usdtContract = network === 'ETH' ? new web3Eth.eth.Contract(ethapproveAbi, environment.ETH_APPROVE) : new web3Bsc.eth.Contract(ethapproveAbi, environment.ETH_APPROVE);
    const usdtContract = new web3Eth.eth.Contract(ethapproveAbi, environment.ETH_APPROVE)
    let balance = await usdtContract.methods.balanceOf(address).call();
    console.log('bal', balance)
    return balance;
  }

  async approve(usdtAddress, spender, amount, network){
    console.log("approve amount",amount);
    const usdtContract = network === 'ETH' ? new web3Eth.eth.Contract(ethapproveAbi, environment.ETH_APPROVE) : new web3Bsc.eth.Contract(ethapproveAbi, environment.ETH_APPROVE);
    let approveAbi = await usdtContract.methods.approve(environment.ETH_SWAP_CONTRACT, amount).encodeABI();
    return approveAbi;
  }

  async allowance(usdtAddress, owner, spender, network){
    console.log("owner",owner);
    console.log("spender",spender);
    const usdtContract = network === 'ETH' ? new web3Eth.eth.Contract(ethapproveAbi, environment.ETH_APPROVE) : new web3Bsc.eth.Contract(ethapproveAbi, environment.ETH_APPROVE);
    return(await usdtContract.methods.allowance(owner, environment.ETH_SWAP_CONTRACT).call());
  }
  
  async decimals(){
    return(await ethapproveContract.methods.decimals().call());
  }

  async swap(amount, usdtAmount, network){
    console.log("swap amount",amount);
    let swapABI = network === 'ETH' ? await ethContract.methods.swap(amount, usdtAmount).encodeABI() : await bscContract.methods.swap(amount, usdtAmount).encodeABI();
    return swapABI;
  }
}
