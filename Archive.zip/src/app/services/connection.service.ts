import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConnectionService {

    private connection$ = new BehaviorSubject<any>({});
    public listenConnection$ = this.connection$.asObservable();

    constructor() {}

    setConnection(connection: any) {
        this.connection$.next(connection);
    }
}
