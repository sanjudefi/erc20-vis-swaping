import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PricingService {

  constructor(private http: HttpClient) { }

  getPrice(){
    return this.http.get('https://api.coingecko.com/api/v3/simple/price?ids=ekta-2&vs_currencies=USD');  
  }
}
