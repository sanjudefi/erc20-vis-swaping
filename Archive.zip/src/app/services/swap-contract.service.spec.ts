import { TestBed } from '@angular/core/testing';

import { SwapContractService } from './swap-contract.service';

describe('SwapContractService', () => {
  let service: SwapContractService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SwapContractService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
