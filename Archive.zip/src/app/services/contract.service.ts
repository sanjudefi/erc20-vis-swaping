import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod'; 
import Web3 from 'web3';  

const swapAbi = require('src/contracts/abi/bscswap.json');
const evisAbi = require('src/contracts/abi/evs.json');

const web3Bsc = new Web3(environment.BSC_PROVIDER);
const web3ekta = new Web3(environment.EKTA_PROVIDER);

const Contract = new web3Bsc.eth.Contract(swapAbi, environment.SWAP);
const evisContract = new web3ekta.eth.Contract(evisAbi, environment.EVIS_CONTRACT);

@Injectable({
  providedIn: 'root'
})
export class ContractService {

  constructor() { }

  async stakedAmountOf(address){
    let balance = await Contract.methods.stakedAmountOf(address).call();
    return balance;
  }

  /**
   * 
   * @param address 
   * @returns balance
   */
  async getEvisBalance(address) {
    let balance = await evisContract.methods.balanceOf(address).call();
    return balance;
  }
}
