import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class WyreService {


  constructor(private http: HttpClient) { }

  order(amount, address, country, currency = 'USDT') {
    const options = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${environment.WYRE_SECRET}`
      },
      body: JSON.stringify({
        destAmount: amount,
        paymentMethod: 'debit-card',
        amountIncludeFees: false,
        sourceCurrency: 'USD',
        destCurrency: currency,
        redirectUrl: 'https://get.havenft.io',
        failureRedirectUrl: 'https://get.havenft.io/buy-usdt',
        referrerAccountId: environment.WYRE_ACCOUNT_ID,
        dest: `ethereum:${address}`,
        country: country || "US"
      })
    };
    
    return fetch(`${environment.WYRE_API}/orders/reserve`, options)
      .then(response => response.json())
      .then(response => response)
      .catch(err => err);
  }

  getCountries(){
    return this.http.get(`${environment.WYRE_API}/widget/supportedCountries`);
  }
}
