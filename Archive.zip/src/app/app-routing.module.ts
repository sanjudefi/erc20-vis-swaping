import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BuyVistTokenComponent } from './pageComponents/buy-vist-token/buy-vist-token.component';
import { SwapUsdtComponent } from './pageComponents/swap-usdt/swap-usdt.component';
import { WireEthComponent } from './pageComponents/wire-eth/wire-eth.component';
import { WyreComponent } from './pageComponents/wyre/wyre.component';

const routes: Routes = [
  {path:'', component:BuyVistTokenComponent},
  {path:'swap', component: SwapUsdtComponent},
  {path: 'wyre', component:WyreComponent},
  { path: 'wyre-eth', component: WireEthComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
