import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../services/account.service'

import { StorageService } from 'src/app/services/storage.service';
import { environment } from 'src/environments/environment.prod';

import Web3 from 'web3';
import { ConnectionService } from 'src/app/services/connection.service';
const web3 = new Web3(window['ethereum'] || environment.BSC_PROVIDER);

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  account: any = {};
  ethereum: any;

  constructor(     
    private accountService: AccountService, 
    private storageService: StorageService, 
    private connectionService: ConnectionService
  ) { }

  ngOnInit(): void {
    this.account = this.storageService.getItem('account') === null ? { address: "", network: "", chainId: "", provider: "" } : JSON.parse(this.storageService.getItem('account'));
    this.accountService.account.subscribe(response => {
      this.account = response;
    })
  }
  showMobileMenu = false;
  toggleNavbar() {
    this.showMobileMenu = !this.showMobileMenu;
  }

  public async setAccount(address, chainId, provider) {
    let account;
    if (address != "") {
      account = { address: address, chainId: chainId, network: await this.setNetwork(chainId), provider: provider }
    } else {
      account = { address: "", network: "", chainId: "", provider: "" };
    }
    if (address == undefined) {
      account = { address: "", network: "", chainId: "", provider: "" };
    }
    this.accountService.setAccount(account);
    this.account = Object.assign({}, account);
    this.storageService.setItem('account', JSON.stringify(this.account));
    
  }

  public setNetwork(chainId) {
    let network;
    switch (chainId) {
      case '0x1':
      case 1:
        network = "Mainnet";
        break;
      case '0x4':
      case 4:
        network = "Rinkeby";
        break;
      case '0x38':
      case 56:
        network = 'BSC Mainnet';
        break;
      case '0x61':
      case 97:
        network = 'BSC Testnet';
        break;
      case '0x3ec':
      case 1004:
        network = 'EktaChain Testnet';
        break;
      case '0x7ca':
      case 1994:
        network = 'EktaChain';
        break;
      default:
        network = 'Unknown';
        break;
    }
    return network;
  }

  async connect(){
    let account = { status: true };
    this.accountService.connectionStatus(account);
    this.ethereum = window['ethereum'];
    const accounts = await this.ethereum.request({ method: 'eth_requestAccounts' });
    console.log(accounts);
    this.setAccount(accounts[0], this.ethereum.chainId, 'metamask');
    this.connectionService.setConnection(accounts[0]);
    setTimeout(()=>{
      this.account = this.storageService.getItem('account') === null ? { address: "", network: "", chainId: "", provider: "" } : JSON.parse(this.storageService.getItem('account'));
    }, 1000)
  }

  async disconnect(){
    this.storageService.setItem('walletconnect', "");
     this.account = { address: "", network: "", chainId: "", provider: "" };
    this.accountService.setAccount(this.account);
    this.account = Object.assign({}, this.account);
    this.storageService.setItem('account', JSON.stringify(this.account));
    this.ethereum = window['ethereum'];
    await this.ethereum.request({
      method: "eth_requestAccounts",
      params: [{eth_accounts: {}}]
    })
  }
}
