module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    backgroundColor: {
      'primary' : '#e0dfde',
      'secondary': '#005aff',
      'accent' : '#141414',
      'highlight' : 'rgba(0, 90, 255, 0.07)',
      'white' : "#fff",
      'grey' : '#e9e9e9',
      'blue' : '#005aff'
    },
    colors :{
      'primary': '#141414',
      'secondary' : '#e0dfde',
      'grey' : '#555555',
      'white' : '#fff',
      'blue' : '#005aff'
    },
    borderColor: {
      'grey' : '#cccbca',
      'primary' : '#141414',
      'blue' : '#005aff'
    },
    extend: {},
  },
  plugins: [],
}